<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Team extends Model
{
    protected $fillable = ['user_id', 'country'];

    protected function casts(): array
    {
        return ['submitted_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function participants(): HasMany
    {
        return $this->hasMany(Participant::class);
    }

    public function isSubmitted(): bool
    {
        return $this->submitted_at !== null;
    }

    /** Xabar oluvchi tashkilotchilar: .env dagi ro'yxat, bo'sh bo'lsa — administratorlar */
    public static function organizerEmails(): array
    {
        $emails = config('iao.organizer_emails');

        return $emails ?: User::where('is_admin', true)->pluck('email')->all();
    }

    public static function deadlinePassed(): bool
    {
        $deadline = config('iao.registration_deadline');

        return $deadline && now()->greaterThan(Carbon::parse($deadline)->endOfDay());
    }
}

<?php

namespace App\Notifications;

use App\Models\Team;
use App\Support\Olympiad;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** To the responsible person: the application was not approved (English / Russian). */
class TeamRejected extends Notification
{
    public function __construct(private Team $team) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $reason = trim((string) $this->team->rejection_reason);
        $mail = (new MailMessage)
            ->subject(Olympiad::shortName() . ": application not approved — {$this->team->country} / Заявка не подтверждена")
            ->greeting("Dear {$notifiable->name},")
            ->line('The Organising Committee could not approve the application of the team of ' . $this->team->country . '.');
        if ($reason !== '') $mail->line("Reason: {$reason}");

        $mail->line('—')->line('Оргкомитет не смог подтвердить заявку команды «' . $this->team->country . '».');
        if ($reason !== '') $mail->line("Причина: {$reason}");

        return $mail->line('Please contact the organisers if you have questions. / Если у вас есть вопросы, свяжитесь с оргкомитетом.');
    }
}

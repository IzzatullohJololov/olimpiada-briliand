<?php

namespace App\Models;

use App\Support\Olympiad;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Team extends Model
{
    public const PENDING = 'pending';
    public const APPROVED = 'approved';
    public const REJECTED = 'rejected';

    protected $fillable = ['user_id', 'country'];

    protected function casts(): array
    {
        return [
            'submitted_at' => 'datetime',
            'approved_at' => 'datetime',
            'rejected_at' => 'datetime',
            'archived_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function participants(): HasMany
    {
        return $this->hasMany(Participant::class);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->whereNull('archived_at');
    }

    public function isSubmitted(): bool
    {
        return $this->submitted_at !== null;
    }

    public function isApproved(): bool
    {
        return $this->status === self::APPROVED;
    }

    public function isArchived(): bool
    {
        return $this->archived_at !== null;
    }

    /** Xabar oluvchi tashkilotchilar: .env dagi ro'yxat, bo'sh bo'lsa — administratorlar */
    public static function organizerEmails(): array
    {
        $emails = config('iao.organizer_emails');

        return $emails ?: User::where('is_admin', true)->pluck('email')->all();
    }

    /** The registration window set in the admin panel has closed: teams can no longer change their lists. */
    public static function deadlinePassed(): bool
    {
        return Olympiad::registrationStatus() === 'closed';
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ParticipantResource;
use App\Models\Participant;
use App\Models\Team;
use App\Notifications\TeamReopened;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AdminController extends Controller
{
    /** Ustun tartibi (CSV eksport) — anketadagi band tartibida */
    private const CSV_COLUMNS = [
        'status', 'student_group', 'previous_prizewinner', 'needs_visa_invitation',
        'family_name_en', 'first_name_en', 'family_name_native', 'first_name_native',
        'birth_date', 'birth_place', 'sex',
        'citizenship', 'other_citizenships', 'ethnicity', 'previous_visits_uz',
        'passport_number', 'passport_issue_date', 'passport_expiry_date', 'passport_issued_by',
        'passport_scan_path', 'face_photo_path',
        'position', 'org_name', 'org_location', 'org_address', 'org_contacts', 'graduation_date', 'previous_olympiads',
        'home_location', 'home_address', 'home_phone', 'mobile_phone', 'email',
        'official_language', 'native_languages',
        'diet', 'food_notes', 'medical_notes', 'tshirt_size',
        'emergency_family_name', 'emergency_first_name', 'emergency_relation', 'emergency_age',
        'emergency_languages', 'emergency_phones', 'emergency_email', 'emergency_telegram',
    ];

    public function teams(): JsonResponse
    {
        $teams = Team::query()
            ->with('user:id,name,email')
            ->withCount([
                'participants',
                'participants as leaders_count' => fn ($q) => $q->whereIn('status', ['team_leader', 'team_leader_jury']),
                'participants as observers_count' => fn ($q) => $q->where('status', 'observer'),
                'participants as students_count' => fn ($q) => $q->where('status', 'student'),
            ])
            ->orderBy('country')
            ->get();

        return response()->json($teams);
    }

    public function showTeam(Team $team): JsonResponse
    {
        return response()->json([
            'team' => $team->load('user:id,name,email'),
            'participants' => ParticipantResource::collection($team->participants()->orderBy('id')->get()),
        ]);
    }

    /** Qulflangan jamoani qayta ochish (xato topilganda) */
    public function reopen(Team $team): JsonResponse
    {
        $team->update(['submitted_at' => null]);

        try {
            $team->user->notify(new TeamReopened($team));
        } catch (\Throwable $e) {
            report($e);
        }

        return response()->json(['message' => "{$team->country} jamoasi qayta ochildi.", 'team' => $team]);
    }

    public function file(string $participant, string $type): StreamedResponse
    {
        $model = Participant::findOrFail($participant);
        $path = $type === 'passport' ? $model->passport_scan_path : $model->face_photo_path;

        abort_if(!$path || !Storage::disk('local')->exists($path), 404);

        return Storage::disk('local')->download($path);
    }

    /** Barcha jamoalar ishtirokchilari — CSV (Excel UTF-8 BOM bilan to'g'ri ochadi) */
    public function exportCsv(): StreamedResponse
    {
        $filename = 'iao2026_participants_' . now()->format('Ymd_His') . '.csv';

        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, array_merge(['country', 'team_submitted'], self::CSV_COLUMNS));

            foreach (Participant::with('team')->orderBy('team_id')->orderBy('id')->cursor() as $p) {
                $row = [$p->team->country, $p->team->isSubmitted() ? 'yes' : 'no'];
                foreach (self::CSV_COLUMNS as $col) {
                    $v = $p->{$col};
                    if ($v instanceof \Carbon\CarbonInterface) $v = $v->format('d.m.Y');
                    if (is_bool($v)) $v = $v ? 'yes' : 'no';
                    $row[] = self::safeCell($v);
                }
                fputcsv($out, $row);
            }

            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    /** CSV-injection himoyasi: =, @ bilan boshlansa yoki telefon bo'lmagan +/- bo'lsa — oldiga ' qo'yiladi */
    private static function safeCell(mixed $v): mixed
    {
        if (!is_string($v) || $v === '') return $v;

        $first = $v[0];
        if ($first === '=' || $first === '@' || $first === "\t" || $first === "\r") return "'" . $v;
        if (($first === '+' || $first === '-') && !preg_match('/^[+\-][0-9 ()\-]+$/', $v)) return "'" . $v;

        return $v;
    }
}

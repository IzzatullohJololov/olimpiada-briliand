<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;
use App\Models\Team;
use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Auth\Events\Verified;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /** Davlat jamoasini ro'yxatdan o'tkazish: user + team yaratadi, tasdiqlash xati yuboradi, token qaytaradi */
    public function register(RegisterRequest $request): JsonResponse
    {
        $user = DB::transaction(function () use ($request) {
            $user = User::create($request->safe()->only(['name', 'email', 'password']));
            Team::create(['user_id' => $user->id, 'country' => $request->validated('country')]);

            return $user;
        });

        $this->sendVerification($user);

        return response()->json([
            'user' => $user->load('team'),
            'token' => $user->createToken('api')->plainTextToken,
            'message' => 'Emailingizga tasdiqlash havolasi yuborildi.',
        ], 201);
    }

    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        if (!Auth::attempt($credentials)) {
            throw ValidationException::withMessages(['email' => ['Email yoki parol noto\'g\'ri.']]);
        }

        $user = $request->user();

        return response()->json([
            'user' => $user->load('team'),
            'token' => $user->createToken('api')->plainTextToken,
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Chiqildi.']);
    }

    public function me(Request $request): JsonResponse
    {
        return response()->json($request->user()->load('team'));
    }

    /** Email havolasi (imzolangan URL): GET /api/auth/email/verify/{id}/{hash} — token talab qilinmaydi */
    public function verifyEmail(Request $request, string $id, string $hash): JsonResponse|RedirectResponse
    {
        $user = User::findOrFail($id);

        abort_unless(hash_equals(sha1($user->getEmailForVerification()), $hash), 403, 'Havola noto\'g\'ri.');

        if (!$user->hasVerifiedEmail()) {
            $user->markEmailAsVerified();
            event(new Verified($user));
        }

        // Frontend bo'lsa o'shanga yo'naltiramiz, bo'lmasa JSON
        if ($request->boolean('json') || !config('iao.frontend_url')) {
            return response()->json(['message' => 'Email tasdiqlandi.']);
        }

        return redirect()->away(config('iao.frontend_url') . '/email-verified');
    }

    public function resendVerification(Request $request): JsonResponse
    {
        $user = $request->user();

        if ($user->hasVerifiedEmail()) {
            return response()->json(['message' => 'Email allaqachon tasdiqlangan.']);
        }

        $this->sendVerification($user);

        return response()->json(['message' => 'Tasdiqlash havolasi qayta yuborildi.']);
    }

    /** Parolni tiklash havolasini yuborish. Email bor-yo'qligini oshkor qilmaydi (har doim bir xil javob). */
    public function forgotPassword(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required', 'email']]);

        Password::sendResetLink($request->only('email'));

        return response()->json(['message' => 'Agar bu email ro\'yxatdan o\'tgan bo\'lsa, parolni tiklash havolasi yuborildi.']);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'token' => ['required', 'string'],
            'email' => ['required', 'email'],
            'password' => ['required', 'confirmed', PasswordRule::min(8)],
        ]);

        $status = Password::reset($data + ['password_confirmation' => $request->input('password_confirmation')],
            function (User $user, string $password) {
                $user->forceFill(['password' => $password])->save();
                $user->tokens()->delete();                       // barcha eski tokenlar bekor
                event(new PasswordReset($user));
            });

        if ($status !== Password::PASSWORD_RESET) {
            throw ValidationException::withMessages(['email' => ['Havola yaroqsiz yoki muddati tugagan.']]);
        }

        return response()->json(['message' => 'Parol yangilandi. Qaytadan kiring.']);
    }

    /** Pochta ishlamasa ro'yxatdan o'tish yiqilmasin: xatoni yozib qo'yamiz, foydalanuvchi qayta yuborishi mumkin */
    private function sendVerification(User $user): void
    {
        try {
            $user->sendEmailVerificationNotification();
        } catch (\Throwable $e) {
            report($e);
        }
    }
}

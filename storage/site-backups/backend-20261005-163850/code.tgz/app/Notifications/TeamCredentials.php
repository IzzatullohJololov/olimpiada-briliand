<?php

namespace App\Notifications;

use App\Models\Team;
use App\Support\Olympiad;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** To the responsible person: login and password after approval, or a new password set by the organisers (English / Russian). */
class TeamCredentials extends Notification
{
    public function __construct(private Team $team, private string $password, private bool $reset = false) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $url = config('iao.frontend_url') . '/login';
        $mail = (new MailMessage)
            ->subject(Olympiad::shortName() . ': ' . ($this->reset ? 'new password' : 'your application is approved') . " — {$this->team->country}")
            ->greeting("Dear {$notifiable->name},");

        $mail = $this->reset
            ? $mail->line('The Organising Committee has set a new password for the account of the team of ' . $this->team->country . '.')
            : $mail->line('The application of the team of ' . $this->team->country . ' for the ' . Olympiad::title('en') . ' has been approved.')
                ->line('Sign in to add the team leaders and the students, and submit the final list before the deadline.');

        return $mail
            ->line("Login: {$notifiable->email}")
            ->line("Password: {$this->password}")
            ->action('Sign in / Войти', $url)
            ->line('—')
            ->line($this->reset
                ? 'Оргкомитет установил новый пароль для учётной записи команды «' . $this->team->country . '».'
                : 'Заявка команды «' . $this->team->country . '» на ' . Olympiad::title('ru') . ' подтверждена. Войдите, чтобы добавить руководителей и школьников, и отправьте окончательный список до окончания срока.')
            ->line("Логин: {$notifiable->email}")
            ->line("Пароль: {$this->password}")
            ->line('You can change the password at any time with “Forgot your password?” on the sign-in page. / Пароль можно сменить через «Забыли пароль?» на странице входа.');
    }
}

<?php

namespace App\Notifications;

use App\Models\Team;
use App\Support\Olympiad;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** To the responsible person: the application was received and is waiting for approval (English / Russian). */
class RegistrationReceived extends Notification
{
    public function __construct(private Team $team) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject(Olympiad::shortName() . ": application received — {$this->team->country} / Заявка получена")
            ->greeting("Dear {$notifiable->name},")
            ->line('We have received the application of the team of ' . $this->team->country . ' for the ' . Olympiad::title('en') . '.')
            ->line('The Organising Committee will review it. After approval you will receive your login and password by email.')
            ->line('—')
            ->line('Заявка команды «' . $this->team->country . '» на ' . Olympiad::title('ru') . ' получена.')
            ->line('Оргкомитет рассмотрит её. После подтверждения вы получите логин и пароль по электронной почте.');
    }
}

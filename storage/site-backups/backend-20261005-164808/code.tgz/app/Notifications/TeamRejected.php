<?php

namespace App\Notifications;

use App\Models\Team;
use App\Support\TriMail;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** To the responsible person: the application was not approved. */
class TeamRejected extends Notification
{
    public function __construct(private Team $team) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $c = $this->team->country;
        $hi = TriMail::greetings($notifiable->name);
        $reason = trim((string) $this->team->rejection_reason);
        $why = fn (string $label) => $reason !== '' ? ["{$label}: {$reason}"] : [];

        return TriMail::make(
            ['en' => 'Application not approved', 'ru' => 'Заявка не подтверждена', 'uz' => 'Ariza tasdiqlanmadi'],
            [
                'en' => [$hi['en'], "The Organising Committee could not approve the application of the team of {$c}.", ...$why('Reason'),
                    'If you have questions, please contact the Organising Committee.'],
                'ru' => [$hi['ru'], "Оргкомитет не смог подтвердить заявку команды «{$c}».", ...$why('Причина'),
                    'Если у вас есть вопросы, свяжитесь с оргкомитетом.'],
                'uz' => [$hi['uz'], "Tashkiliy qoʻmita {$c} jamoasining arizasini tasdiqlay olmadi.", ...$why('Sabab'),
                    'Savollaringiz boʻlsa, tashkiliy qoʻmita bilan bogʻlaning.'],
            ],
            suffix: $c,
        );
    }
}

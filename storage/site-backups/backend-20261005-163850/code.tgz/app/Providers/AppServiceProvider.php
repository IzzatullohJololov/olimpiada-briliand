<?php

namespace App\Providers;

use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // API-only loyihada 'password.reset' veb-marshruti yo'q, shuning uchun havola frontendga olib boradi:
        // {frontend}/reset-password?token=...&email=...
        ResetPassword::createUrlUsing(function ($user, string $token) {
            return config('iao.frontend_url') . '/reset-password?' . http_build_query([
                'token' => $token,
                'email' => $user->getEmailForPasswordReset(),
            ]);
        });
    }
}

<?php

namespace App\Notifications;

use App\Models\Team;
use App\Support\Olympiad;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** Jamoaga: ro'yxat yakuniy yuborilgani haqida tasdiq */
class TeamSubmitted extends Notification
{
    public function __construct(private Team $team) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $mail = (new MailMessage)
            ->subject(Olympiad::shortName() . ": ro'yxat qabul qilindi — {$this->team->country}")
            ->greeting('Assalomu alaykum!')
            ->line("{$this->team->country} jamoasining " . Olympiad::title('uz') . " uchun ro'yxati yakuniy yuborildi.")
            ->line('Yuborilgan vaqt: ' . $this->team->submitted_at?->format('d.m.Y H:i'))
            ->line('Ro\'yxat tarkibi:');

        foreach ($this->team->participants()->orderBy('id')->get() as $p) {
            $mail->line("• {$p->family_name_en} {$p->first_name_en} — " . ucfirst(str_replace('_', ' ', $p->status)));
        }

        return $mail->line("Ma'lumotni o'zgartirish kerak bo'lsa, tashkilotchilarga murojaat qiling — ular ro'yxatni qayta ochadi.");
    }
}

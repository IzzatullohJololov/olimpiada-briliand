<?php

namespace App\Notifications;

use App\Models\Team;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** Jamoaga: ro'yxat tashkilotchi tomonidan qayta ochildi */
class TeamReopened extends Notification
{
    public function __construct(private Team $team) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("IAO 2026: {$this->team->country} ro'yxati qayta ochildi")
            ->line("{$this->team->country} jamoasining ro'yxati tashkilotchilar tomonidan tahrirlash uchun qayta ochildi.")
            ->line("Kerakli o'zgartirishlarni kiriting va ro'yxatni qaytadan yakuniy yuboring.");
    }
}
